# Kite0 v0.1.1 - Source Code & Build Instructions for Mozilla Reviewers

## 1. Environment & Prerequisites
- **Operating System**: Linux (Ubuntu 20.04+ / Debian), macOS (12+), or Windows 10/11
- **Node.js**: >= 18.0.0 (Recommended: v20.x or v22.x LTS)
- **npm**: >= 9.0.0
- **Rust & Cargo**: >= 1.75.0 (Stable toolchain)
- **wasm-pack**: >= 0.12.0 (`cargo install wasm-pack`)

---

## 2. Step-by-Step Build Instructions

### Step 1: Compile the Rust WebAssembly Core Engine
From the repository root:
```bash
cd engine
wasm-pack build --target web --out-dir ../extension/src/wasm/pkg
cd ..
```
This generates the WebAssembly binary and JavaScript bindings at `extension/src/wasm/pkg/`.

### Step 2: Install Extension Dependencies
```bash
cd extension
npm install
```

### Step 3: Build & Package the Extension
```bash
npm run build
node scripts/package.mjs
```

### Output:
The exact Firefox distribution package will be generated at:
`extension/dist-packages/kiteo-firefox-v0.1.1.zip`
and the unpacked directory at:
`extension/dist-firefox/`

---

## 3. Automated Single-Step Build Script
Alternatively, run:
- On Linux/macOS:
  ```bash
  chmod +x build.sh
  ./build.sh
  ```
- On Windows:
  ```cmd
  build.bat
  ```

---

## 4. Notes on Third-Party WebAssembly Binaries
The extension uses standard, open-source tree-sitter wasms (`tree-sitter-cpp.wasm`, `tree-sitter-java.wasm`, and `tree-sitter.wasm`) provided by the audited npm packages `tree-sitter-wasms` (v0.1.13) and `web-tree-sitter` (v0.22.6) for client-side AST parsing.
