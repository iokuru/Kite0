@echo off
echo === Building Kite0 v0.1.1 from Source ===
cd engine
wasm-pack build --target web --out-dir ../extension/src/wasm/pkg
if %errorlevel% neq 0 exit /b %errorlevel%
cd ../extension
call npm install
if %errorlevel% neq 0 exit /b %errorlevel%
call npm run build
if %errorlevel% neq 0 exit /b %errorlevel%
node scripts/package.mjs
if %errorlevel% neq 0 exit /b %errorlevel%
echo === Build Complete! Firefox add-on package: extension/dist-packages/kiteo-firefox-v0.1.1.zip ===
