#!/usr/bin/env bash
set -e
echo "=== Building Kite0 v0.1.1 from Source ==="
cd engine
wasm-pack build --target web --out-dir ../extension/src/wasm/pkg
cd ../extension
npm install
npm run build
node scripts/package.mjs
echo "=== Build Complete! Firefox add-on package: extension/dist-packages/kiteo-firefox-v0.1.1.zip ==="
