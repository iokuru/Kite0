/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const analyze_wasm: (a: number, b: number, c: number, d: number) => [number, number];
export const analyze_wasm_with_ast: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number];
export const preprocess_wasm: (a: number, b: number) => [number, number];
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
