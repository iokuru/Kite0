import"./chunks/modulepreload-polyfill.js";import{a as d,i as y}from"./chunks/analyzer.js";window.kiteoAnalyze=d;const s={linear:{lang:"cpp",code:`void solve(int n) {
    for (int i = 0; i < n; i++) {
        sum += a[i];
    }
}`},nested:{lang:"cpp",code:`void solve(int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            matrix[i][j] = i * j;
        }
    }
}`},two_pointers:{lang:"cpp",code:`bool hasPair(const vector<int>& a, int target) {
    int l = 0, r = a.size() - 1;
    while (l < r) {
        int s = a[l] + a[r];
        if (s == target) return true;
        if (s < target) l++;
        else r--;
    }
    return false;
}`},segtree:{lang:"cpp",code:`struct SegTree {
    int n;
    vector<int> tree;
    SegTree(int n) : n(n), tree(4 * n, 0) {}
    void update(int node, int l, int r, int idx, int val) {
        if (l == r) { tree[node] = val; return; }
        int mid = (l + r) / 2;
        if (idx <= mid) update(2 * node, l, mid, idx, val);
        else update(2 * node + 1, mid + 1, r, idx, val);
        tree[node] = tree[2 * node] + tree[2 * node + 1];
    }
};`},dijkstra:{lang:"java",code:`class Solution {
    public long[] dijkstra(int start, int V, java.util.List<java.util.List<Edge>> g) {
        long[] dist = new long[V];
        java.util.PriorityQueue<long[]> pq = new java.util.PriorityQueue<>();
        dist[start] = 0;
        return dist;
    }
}`},sieve:{lang:"java",code:`class Solution {
    public void sieve(int n) {
        boolean[] isPrime = new boolean[n + 1];
        for (int p = 2; p * p <= n; p++) {
            if (isPrime[p]) for (int i = p * p; i <= n; i += p) isPrime[i] = false;
        }
    }
}`}};let c=!1;async function v(){const t=document.getElementById("status");t&&(t.textContent="Loading WebAssembly engine...");try{await y(),c=!0,t&&(t.textContent="WebAssembly engine loaded ready."),await r()}catch(n){t&&(t.textContent="Failed to load WebAssembly: "+String(n))}}async function r(){if(!c)return;const t=document.getElementById("lang-select"),n=document.getElementById("code-input"),e=document.getElementById("tc-output"),o=document.getElementById("sc-output"),i=document.getElementById("algo-output");if(!t||!n||!e||!o||!i)return;const u=n.value,g=t.value,m=performance.now();try{const a=await d(u,g),p=performance.now();e.textContent=a.tc||"Unknown",o.textContent=a.sc||"Unknown",i.textContent=a.algorithms&&a.algorithms.length>0?a.algorithms.join(", "):"None detected";const l=document.getElementById("status");l&&(l.textContent=`Analyzed locally in ${(p-m).toFixed(2)} ms (Zero network requests)`)}catch{e.textContent="Error",o.textContent="Error",i.textContent="Error"}}window.addEventListener("DOMContentLoaded",()=>{const t=document.getElementById("code-input"),n=document.getElementById("run-btn"),e=document.getElementById("lang-select");t&&(t.value=s.linear.code),document.querySelectorAll(".preset-btn").forEach(o=>{o.addEventListener("click",async()=>{const i=o.getAttribute("data-type");i&&s[i]&&(t&&(t.value=s[i].code),e&&(e.value=s[i].lang),await r())})}),n==null||n.addEventListener("click",r),t==null||t.addEventListener("input",r),e==null||e.addEventListener("change",r),v()});
